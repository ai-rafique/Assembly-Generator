#include <stdio.h>
#include "calc3.h"
#include "y.tab.h"

void print_instruction()
{
	printf("\tpopq\t%%rsi\n");
	printf("\tpushq\t%%rax\n");
	printf("\tpushq\t%%rdx\n");
	printf("\tmovq\t$int_format,%%rdi\n");
	printf("\tmovq\t$0,%%rax\n");
	printf("\tcall\tprintf\n");
	printf("\tpopq\t%%rdx\n");
	printf("\tpopq\t%%rax\n");
}

void uminus_instruction()
{
	printf("\tpopq\t%%rax\n");
	printf("\tnegq\t%%rax\n");
	printf("\tpushq\t%%rax\n");
}

void gcd_instruction()
{
	/*gcd takes 2 values which we pop and call gcd on, the function is defined in the prologue*/
	printf("\tpopq\t%%rdi\n");
	printf("\tpopq\t%%rsi\n");
	printf("\tcall\tgcd\n");
	printf("\tpushq\t%%rax\n");
}

void add_instruction()
{
	printf("\tpopq\t%%rax\n");
	printf("\tpopq\t%%rdx\n");
	printf("\taddq\t%%rax,%%rdx\n");
	printf("\tpushq\t%%rdx\n");
}

void sub_instruction()
{
	printf("\tpopq\t%%rax\n");
	printf("\tpopq\t%%rdx\n");
	printf("\tsubq\t%%rax,%%rdx\n");
	printf("\tpushq\t%%rdx\n");
}

void mul_instruction()
{
	printf("\tpopq\t%%rdi\n");
	printf("\tpopq\t%%rax\n");
	printf("\tmovq\t$0,%%rdx\n"); // going to check whether necessary
	printf("\timulq\t%%rdi\n");
	printf("\tpushq\t%%rax\n");
}

void div_instruction()
{
	/*this wont get the remainder. But can we try ? Hmm, might do so*/
	printf("\tpopq\t%%rdi\n");
	printf("\tpopq\t%%rax\n");
	printf("\tmovq\t$0,%%rdx\n");
	printf("\tidivq\t%%rdi\n");
	printf("\tpushq\t%%rax\n");
}

void jge_instruction(int lbl)
{
	printf("\tpopq\t%%rax\n");
	printf("\tpopq\t%%rdx\n");
	printf("\tcmpq\t%%rax,%%rdx\n");
	printf("\tjge\tL%03d\n", lbl);
}

void jle_instruction(int lbl)
{
	printf("\tpopq\t%%rax\n");
	printf("\tpopq\t%%rdx\n");
	printf("\tcmpq\t%%rax,%%rdx\n");
	printf("\tjle\tL%03d\n", lbl);
}

void ge_instruction(int lbl)
{
	printf("\tpopq\t%%rax\n");
	printf("\tpopq\t%%rdx\n");
	printf("\tcmpq\t%%rax,%%rdx\n");
	printf("\tjl\tL%03d\n", lbl);
}

void le_instruction(int lbl)
{
	printf("\tpopq\t%%rax\n");
	printf("\tpopq\t%%rdx\n");
	printf("\tcmpq\t%%rax,%%rdx\n");
	printf("\tjg\tL%03d\n", lbl);
}
void ne_instruction(int lbl)
{
	printf("\tpopq\t%%rax\n");
	printf("\tpopq\t%%rdx\n");
	printf("\tcmpq\t%%rax,%%rdx\n");
	printf("\tje\tL%03d\n", lbl);
}
void eq_instruction(int lbl)
{
	printf("\tpopq\t%%rax\n");
	printf("\tpopq\t%%rdx\n");
	printf("\tcmpq\t%%rax,%%rdx\n");
	printf("\tjne\tL%03d\n", lbl);
}
static int lbl;

int ex(nodeType *p)
{
	int lbl1, lbl2;

	if (!p)
		return 0;
	switch (p->type)
	{
	case typeCon:
		//printf("\tpush\t%d\n", p->con.value);
		/*This is supposed to be a constant*/
		printf("\tpushq\t$%d\n", p->con.value);
		break;
	case typeId:
		//printf("\tpush\t%c\n", p->id.i + 'a');
		/*This is supposed to be an identifier */
		printf("\tpushq\t%c\n", p->id.i + 'a');
		break;
	case typeOpr: /*entering operations*/
		switch (p->opr.oper)
		{
		case WHILE:
			printf("L%03d:\n", lbl1 = lbl++);
			ex(p->opr.op[0]);
			printf("\tjz\tL%03d\n", lbl2 = lbl++);
			ex(p->opr.op[1]);
			printf("\tjmp\tL%03d\n", lbl1);
			printf("L%03d:\n", lbl2);
			break;
		case IF:
			ex(p->opr.op[0]);
			if (p->opr.nops > 2)
			{
				/* if else */
				printf("\tjz\tL%03d\n", lbl1 = lbl++);
				ex(p->opr.op[1]);
				printf("\tjmp\tL%03d\n", lbl2 = lbl++);
				printf("L%03d:\n", lbl1);
				ex(p->opr.op[2]);
				printf("L%03d:\n", lbl2);
			}
			else
			{
				/* if */
				printf("\tjz\tL%03d\n", lbl1 = lbl++);
				ex(p->opr.op[1]);
				printf("L%03d:\n", lbl1);
			}
			break;
		case PRINT:
			ex(p->opr.op[0]);
			//printf("\tprint\n");
			/*I was getting a massive headache looking at all those instructions
		inside the case statements. Using a header file and calling functions
		from there like the maniac I am.*/
			print_instruction();
			break;
		case '=':
			ex(p->opr.op[1]);
			//printf("\tpop\t%c\n", p->opr.op[0]->id.i + 'a');
			/*this is the assignment =, the == is upcoming*/
			printf("\tpopq\t%c\n", p->opr.op[0]->id.i + 'a');
			break;
		case UMINUS:
			ex(p->opr.op[0]);
			//printf("\tneg\n");
			/*flow is pop the value, negate and then push
		something about 2's complement (I hate DLD) but simply, this is d= d*-1*/
			uminus_instruction();
			break;
		case FACT:
			ex(p->opr.op[0]);
			printf("\tcall fact\n");
			break;
		case LNTWO:
			ex(p->opr.op[0]);
			printf("\tcall lntwo\n");
			break;
		default:
			ex(p->opr.op[0]);
			ex(p->opr.op[1]);
			switch (p->opr.oper)
			{
			case GCD:
				gcd_instruction();
				break;
			case '+':
				/*pop the values, add them and push, more in the header file*/
				add_instruction();
				break;
			case '-': /*cocenptually opposite of add, just use sub methinks*/
				sub_instruction();
				break;
			case '*':
				mul_instruction();
				break;
			case '/':
				div_instruction();
				break;
			case '<':
				jge_instruction(lbl);
				break;
			case '>':
				jle_instruction(lbl);
				break;
			case GE:
				ge_instruction(lbl);
				break;
			case LE:
				le_instruction(lbl);
				break;
			case NE:
				ne_instruction(lbl);
				break;
			case EQ:
				eq_instruction(lbl);
				break;
			}
		}
	}
	return 0;
}

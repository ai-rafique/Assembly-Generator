#!/bin/bash

#Prompts when there are no arguments passed
if [ "$#" -le 0 ]; then
    echo "Usage : $0 <filename.calc>"
    exit 2
fi

if [ ! -r $1 ]; then
    echo -e "File does not exist or not readable"
    exit 2
fi

#Extract the file name
filename=$(basename -- "$1")
filename="${filename%.*}"

#create the .s file
touch outputs/$filename.s

# Add the prologue
cat lexy-acc/prologue > outputs/$filename.s
#Add the actual code
cat $1 | ./bin/calc3i.exe >> outputs/$filename.s
#Add the epilogue	
cat lexy-acc/epilogue >> outputs/$filename.s

# Link compile to get the .o and executable file from .s 
as outputs/$filename.s -o outputs/$filename.o
gcc -o bin/$filename outputs/$filename.o -m64 -fno-pie

#Display the results
./bin/$filename
